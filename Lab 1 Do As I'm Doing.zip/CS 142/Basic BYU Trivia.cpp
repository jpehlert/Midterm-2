/*
 Joey Ehlert, Section 001, joey@ehlert.org
 Ready to Grade
 Purpose: Tell Basic BYU Trivia
 No inputs
 Output: Several Basic BYU Trivia questions and answers
 
 */

#include <iostream>

using namespace std;

int main() {
    
    //Print Title
    cout << "\t\t\t\t\t\t\t\tBasic BYU Trivia\n";
    
    //Establish two columns for questions and for answers
    cout << "\t\t\t\tQuestions\t\t\t\t\t\t\t\tAnswers\n\n";
    
    //Print trivia questions and answers
    cout << "What was the original name of BYU\?\t\t\t\tBrigham Young Academy\n";
    cout << "When was BYA established\?\t\t\t\t\t\t1875\n";
    cout << "Who was the first \"permanant\" principal of BYA\? Karl Maeser\n";
    cout << "When did BYU become BYA\?\t\t\t\t\t\t1903\n";
    cout << "To what sports conference do we belong\?\t\t\tIndependent (Football)\n";
    cout << "When did BYU win the national football title\?\t1984\n";
    cout << "Who won the Heisman Trophy in 1990\?\t\t\t\tTy Detmer\n";
    
    system("pause");
    
    return 0;
    
}
